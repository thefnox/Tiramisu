SCHEMA.Name = "Global";
SCHEMA.Author = "";
SCHEMA.Description = "Make sure you derive this somewhere!";

function SCHEMA.SetUp( )
	
end
