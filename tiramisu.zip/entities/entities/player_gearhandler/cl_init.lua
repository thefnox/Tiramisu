include('shared.lua')

local lolpos

function ENT:Draw()
	return
end